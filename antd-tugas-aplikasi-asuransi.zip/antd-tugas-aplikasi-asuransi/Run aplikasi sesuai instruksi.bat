@echo off
echo Membuka folder project...
cd /d "%~dp0antd-tugas-aplikasi-asuransi"

echo Menginstall dependensi (node_modules)...
call npm install

echo Menjalankan aplikasi...
call npm run dev

pause