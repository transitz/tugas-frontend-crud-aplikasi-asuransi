import { useState, useEffect } from 'react';
import { Table, Form, Input, InputNumber, DatePicker, Button, Select, Space, Popconfirm, Card, message, ConfigProvider, theme } from 'antd';
import dayjs from 'dayjs';
import './App.css'

//Nico Cornelius - Tugas Coding Simple dengan AntDesign React. Tanpa database, data disimpan di local storage browser.

function App() {
  const [form] = Form.useForm();
  const [editingId, setEditingId] = useState(null);

  // Ambil data dari local storage
  const [items, setItems] = useState(() => {
    const savedItems = localStorage.getItem('antd_nicoc_items');
    return savedItems ? JSON.parse(savedItems) : [];
  });

  const hargaKendaraan = Form.useWatch('hargaKendaraan', form);
  const ratePremi = Form.useWatch('ratePremi', form);

  // Auto Hitung Harga Premi setiap ada perubahan hargaKendaraan atau ratePremi
  useEffect(() => {
    if (hargaKendaraan && ratePremi) {
      // Harga Premi = (ratePremi / 100) * hargaKendaraan
      const calculatedHargaPremi = Math.round((Number(ratePremi) / 100) * Number(hargaKendaraan));

      // Update nilai di form
      form.setFieldValue('hargaPremi', calculatedHargaPremi);
    } else {
      form.setFieldValue('hargaPremi', undefined);
    }
  }, [hargaKendaraan, ratePremi, form]);

  // Auto Save data tabel ke local storage setiap ada perubahan data pada tabel
  useEffect(() => {
    localStorage.setItem('antd_nicoc_items', JSON.stringify(items));
  }, [items]);

  // Form Submit (Add dan Edit)
  const onFinish = (values) => {
    const formattedTglEfektif = values.tglEfektif ? values.tglEfektif.format('YYYY-MM-DD') : '';
    const formattedTglExpired = values.tglExpired ? values.tglExpired.format('YYYY-MM-DD') : '';

    if (editingId) {
      // EDIT--------------------------------------
      setItems(items.map(item =>
        item.id === editingId
          ?
          {
            ...item,
            // id dan nomorPolis tidak boleh di-edit,
            namaTertanggung: values.namaTertanggung,
            tglEfektif: formattedTglEfektif,
            tglExpired: formattedTglExpired,
            merkKendaraan: values.merkKendaraan,
            tipeKendaraan: values.tipeKendaraan,
            tahunKendaraan: values.tahunKendaraan,
            hargaKendaraan: values.hargaKendaraan,
            ratePremi: values.ratePremi,
            hargaPremi: values.hargaPremi,
          }
          : item
      ));
      message.success('Item updated successfully!');
      setEditingId(null);
    } else {
      // ADD--------------------------------------
      //ID incremental sbg No. Urut
      const nextId = items.length > 0 ? Math.max(...items.map(item => item.id)) + 1 : 1;

      //TGL pemasukkan data utk No. Polis
      const today = dayjs().format('YYYYMMDD');

      //No. Polis = TGL hari ini + No. Urut
      const nomorPolis = `${today}${nextId}`;

      const newItem = {
        id: nextId,
        nomorPolis: nomorPolis,
        namaTertanggung: values.namaTertanggung,
        tglEfektif: formattedTglEfektif,
        tglExpired: formattedTglExpired,
        merkKendaraan: values.merkKendaraan,
        tipeKendaraan: values.tipeKendaraan,
        tahunKendaraan: values.tahunKendaraan,
        hargaKendaraan: values.hargaKendaraan,
        ratePremi: values.ratePremi,
        hargaPremi: values.hargaPremi
      };
      setItems([...items, newItem]);
      message.success('Data Berhasil Ditambahkan');
    }
    form.resetFields();
  };

  // Data dari record (react state array) ke Form utk EDIT
  const startEdit = (record) => {
    setEditingId(record.id);
    form.setFieldsValue({
      nomorPolis: record.nomorPolis,
      namaTertanggung: record.namaTertanggung,
      tglEfektif: dayjs(record.tglEfektif),
      tglExpired: dayjs(record.tglExpired),
      merkKendaraan: record.merkKendaraan,
      tipeKendaraan: record.tipeKendaraan,
      tahunKendaraan: record.tahunKendaraan,
      hargaKendaraan: record.hargaKendaraan,
      ratePremi: record.ratePremi,
      hargaPremi: record.hargaPremi
    });
  };

  // DELETE--------------------------------------
  const deleteItem = (id) => {
    setItems(items.filter(item => item.id !== id));

    //Reset Form jika klik delete pada data yg lagi diedit
    if (id === editingId) {
      setEditingId(null);
      form.resetFields();
    }

    message.error('Data Berhasil Dihapus');
  };

  // Cancel Edit--------------------------------------
  const cancelEdit = () => {
    setEditingId(null);
    form.resetFields();
  };

  // AntD Kolom Tabel
  // !!!! 'dataIndex' string harus sama dengan object keys dalam record state!!!!!!!
  const columns = [
    {
      title: "No.",
      key: "index",
      render: (_, __, index) => index + 1, // nomor urut display tabel (bukan nomor urut ID)
    },
    {
      title: 'Nomor Polis',
      dataIndex: 'nomorPolis', // ambil dari record.nomorPolis (record dari data react state array)
      key: 'nomorPolis'
    },
    {
      title: 'Nama Tertanggung',
      dataIndex: 'namaTertanggung',
      key: 'namaTertanggung'
    },
    {
      title: 'Periode',
      key: 'periode',
      render: (_, record) =>
        `${dayjs(record.tglEfektif).format('YYYY/MM/DD')} - ${dayjs(record.tglExpired).format('YYYY/MM/DD')}`,
    },
    {
      title: 'Nama Item',
      key: 'namaItem',
      render: (_, record) => `${record.merkKendaraan} - ${record.tipeKendaraan}`,
    },
    {
      title: 'Tahun Kendaraan',
      dataIndex: 'tahunKendaraan',
      key: 'tahunKendaraan'
    },
    {
      title: 'Harga Pertanggungan',
      dataIndex: 'hargaKendaraan',
      key: 'hargaKendaraan',
      render: (value) => {
        if (!value && value !== 0) return '-';

        // Format angka ke Rupiah pada tabel
        return new Intl.NumberFormat('id-ID', {
          style: 'currency',
          currency: 'IDR',
          maximumFractionDigits: 0, // tidak pakai desimal sen ",00" 
        }).format(value);
      }
    },
    {
      title: 'Harga Premi',
      dataIndex: 'hargaPremi',
      key: 'hargaPremi',
      render: (value) => {
        if (!value && value !== 0) return '-';

        // Format angka ke Rupiah pada tabel
        return new Intl.NumberFormat('id-ID', {
          style: 'currency',
          currency: 'IDR',
          maximumFractionDigits: 0, // tidak pakai desimal sen ",00" 
        }).format(value);
      }
    },
    /* //rate premi tidak di-display pada tabel sesuai soal coding
    {
      title: 'Rate Premi',
      dataIndex: 'ratePremi',
      key: 'ratePremi',
      render: (value) => {
        if (value === null || value === undefined) return '-';

        // convert float ke format desimal indo dgn koma
        const formattedValue = Number(value).toLocaleString('id-ID', {
          minimumFractionDigits: 0,
          maximumFractionDigits: 2, // max 2 digit dibelakang koma
        });

        return `${formattedValue}%`;
      },
    },*/
    {
      title: 'Aksi',
      key: 'aksi',
      render: (_, record) => (
        <Space size="middle">
          <Button type="link" onClick={() => startEdit(record)}>Edit</Button>
          <Popconfirm
            title="Anda yakin ingin hapus data ini?"
            onConfirm={() => deleteItem(record.id)}
            okText="Ya"
            cancelText="Tidak"
          >
            <Button type="link" danger>Delete</Button>
          </Popconfirm>
        </Space>
      ),
    },
  ];

  return (
    <>
      <ConfigProvider
        theme={{
          algorithm: theme.darkAlgorithm,
        }}
      >

        <div style={{ maxWidth: '100%', margin: '50px auto', padding: '0 20px' }}>

          {/* Dynamic Title based on whether editing or adding */}
          <Card title={editingId ? '✏️ Edit Data' : '➕ Tambah Data Baru'} style={{ marginBottom: '30px' }}>
            <Form
              form={form}
              layout="horizontal"
              labelCol={{ span: 8 }}   
              wrapperCol={{ span: 16 }} 
              labelAlign="right"
              style={{ maxWidth: '500px', margin: '0 auto' }}
              onFinish={onFinish}
            >

              {Boolean(editingId) && ( // nomorPolis hanya muncul saat edit data
                <Form.Item name="nomorPolis" label="Nomor Polis"
                >
                  <Input placeholder="Nomor Polis" readOnly
                    //variant="borderless"
                    style={{ width: 180, fontWeight: 'bold' }}
                  />
                </Form.Item>)}

              <Form.Item name="namaTertanggung" label="Nama Tertanggung"
                rules={[{ required: true, message: 'Isi Nama Tertanggung' }]}
              >
                <Input placeholder="Nama Tertanggung" style={{ width: 180 }} />
              </Form.Item>

              <Form.Item name="tglEfektif" label="Tanggal Efektif"
                rules={[{ required: true, message: 'isi tanggal efektif' }]}
              >
                <DatePicker placeholder="Select Date" style={{ width: 150 }} />
              </Form.Item>

              <Form.Item name="tglExpired" label="Tanggal Expired"
                dependencies={['tglEfektif']} // Dependencies agar tglExpired tervalidasi lagi saat tglEfektif berubah
                rules={[
                  { required: true, message: 'Isi tanggal expired' },
                  ({ getFieldValue }) => ({
                    validator(_, value) {
                      const tglEfektif = getFieldValue('tglEfektif');
                      // Jika kedua tanggal diisi dan tglExpired <= tglEfektif
                      if (!value || !tglEfektif || value.isAfter(tglEfektif)) {
                        return Promise.resolve();
                      }
                      return Promise.reject(new Error('Tanggal expired harus setelah tanggal efektif!'));
                    },
                  }),
                ]}
              >
                <DatePicker placeholder="Select Date" style={{ width: 150 }} />
              </Form.Item>

              <Form.Item name="merkKendaraan" label="Merk Kendaraan"
                rules={[{ required: true, message: 'isi merk kendaraan' }]}
              >
                <Input placeholder="Merk Kendaraan" style={{ width: 180 }} />
              </Form.Item>

              <Form.Item name="tipeKendaraan" label="Tipe Kendaraan"
                rules={[{ required: true, message: 'isi tipe kendaraan' }]}
              >
                <Select
                  placeholder="Tipe Kendaraan"
                  style={{ width: 180 }}
                  options={[
                    { value: 'Roda 2', label: 'Roda 2' },
                    { value: 'Roda 4', label: 'Roda 4' },
                    { value: 'Roda > 4', label: 'Roda > 4' },
                  ]} />
              </Form.Item>

              <Form.Item name="tahunKendaraan" label="Tahun Kendaraan"
                rules={[{ required: true, message: 'isi tahun kendaraan' }]}
              >
                <InputNumber
                  min={1800}
                  max={new Date().getFullYear() + 1}
                  placeholder="Tahun Kendaraan"
                  style={{ width: 180 }}
                />
              </Form.Item>

              <Form.Item name="hargaKendaraan" label="Harga Kendaraan"
                rules={[{ required: true, message: 'isi harga kendaraan' }]}
              >
                <InputNumber
                  min={1}
                  placeholder="Harga Kendaraan"
                  style={{ width: 180 }}

                  // view format rupiah "Rp 20.000.000" di layar form
                  formatter={(value) =>
                    value ? `Rp ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, '.') : ''
                  }

                  // view harga ke bentuk angka biasa (20000000) untuk form dan state
                  parser={(value) =>
                    value ? value.replace(/Rp\s?|(\.*)/g, '') : ''
                  }
                />
              </Form.Item>

              <Form.Item name="ratePremi" label="Rate Premi (%)"
                rules={[{ required: true, message: 'isi rate premi' }]}
              >
                <InputNumber
                  min={0.01}
                  step={0.01}
                  precision={2} //max 2 angka belakang koma
                  placeholder="Rate Premi"
                  style={{ width: 180 }}

                  // view format koma dan simbol persen % (Contoh: 3.25 -> "3,25%")
                  formatter={(value) => {
                    if (value === null || value === undefined || value === '') return '';
                    // ganti titik menjadi koma untuk view layar
                    const strVal = String(value).replace('.', ',');
                    return `${strVal}%`;
                  }}

                  // view format angka ke bentuk float untuk form dan state (Contoh: "3,25%" -> "3.25")
                  parser={(value) => {
                    if (!value) return '';
                    // Hapus simbol % dan ubah koma kembali menjadi titik desimal
                    const ratePremiTrimmed = value.replace('%', '').replace(',', '.').trim();
                    return ratePremiTrimmed;
                  }}
                />
              </Form.Item>

              <Form.Item name="hargaPremi" label="Harga Premi">
                <InputNumber
                  readOnly
                  placeholder="Harga Premi"
                  style={{ width: 180 }}

                  // Format visual Rupiah di input field
                  formatter={(value) =>
                    value ? `Rp ${value}`.replace(/\B(?=(\d{3})+(?!\d))/g, '.') : ''
                  }
                  parser={(value) =>
                    value ? value.replace(/Rp\s?|(\.*)/g, '') : ''
                  }
                />
              </Form.Item>

              <Form.Item>
                <Space>
                  <Button type="primary" htmlType="submit">
                    {editingId ? 'Save' : 'Add'}
                  </Button>
                  {editingId && <Button onClick={cancelEdit}>Cancel</Button>}
                </Space>
              </Form.Item>
            </Form>
          </Card>

          <Table
            dataSource={items}
            columns={columns}
            rowKey="id"
          />

        </div>
      </ConfigProvider>
    </>
  )
}

export default App
